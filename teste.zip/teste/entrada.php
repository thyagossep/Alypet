<!DOCTYPE html>
<html> 
    <head> 
        <title>Pagina de entrada</title>
        <meta charset="utf-8">
    </head>
    <body>
        <?php
        $nome = $_GET['nome'];
        echo "Bem-Vindo, $nome!";
        ?>
    </body>
</html>
