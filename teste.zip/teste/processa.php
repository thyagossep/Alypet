<?php 
include_once("conexao.php");

$nome = $_POST['nomeCliente'];
$sobrenome = $_POST['sobrenomeCliente'];
$cpf = $_POST['CPF'];
$sexo = $_POST['sexoCliente'];

if (!$strcon) {
    die('Não foi possivel conectar ao banco de dados');
}


$sql = "INSERT INTO Cadastro(NomeCliente, SobrenomeCliente, SexoCliente, CPF) VALUES('$nome', '$sobrenome', '$sexo', '$cpf')";

$res = mysqli_query($strcon,$sql) or die("Erro de inserção");

echo "Dados cadastrados com sucesso!<br>";
echo "<br><a href='index.html'>Pàgina inicial </a>";

mysqli_close($strcon);
?>