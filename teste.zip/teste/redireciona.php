<?php
function redirecionar($nova_pagina) {
    header("Location: ".$nova_pagina);
}

$nome = $_GET['nome'];
$sobrenome = $_GET['sobrenome'];
$logado = $_GET['logado'];

if($logado == 1) {
    redirecionar("entrada.php?nome=$nome&sobrenome=$sobrenome");
}
else {
    echo "Nome do usuário: ".$nome." ".$sobrenome."<br>";
    echo "Status do usuário: ".$logado."<br>";
    echo "Acesso negado!";
    echo "<br><a href='formulario.html'>Voltar</a>";
}
?>