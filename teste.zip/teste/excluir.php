<?php
include_once("conexao.php");

$nome = $_POST['nomeCliente'];

$sql = "DELETE FROM Cadastro WHERE NomeCliente = '$nome'";

mysqli_query($strcon, $sql) or die("Erro");

if(mysqli_affected_rows($strcon)) {
    echo "Cliente excluido";
}

else {
    die("Erro ao excluir registro");
}

mysqli_close($strcon);

header("refresh:5,url=consulta.html");

?>