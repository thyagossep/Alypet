<?php   
include_once("conexao.php");

$nome = $_POST["nome"];
$sobrenome = $_POST["sobrenome"];
$sexo = $_POST["sexo"];


$sql = "UPDATE Cadastro
        SET SobrenomeCliente = '$sobrenome',
            SexoCliente = '$sexo'
            WHERE NomeCliente = '$nome'";
mysqli_query($strcon,$sql) or die("Erro ao tentar atualizar registro");

//Verificar se algum registro foi alterado ou não
if (mysqli_affected_rows($strcon)) {
    echo "Cliente alterado com successo.";
    echo "Aguarde e será redirecionado a página de consulta.";
}
else{
    mysqli_close($strcon);
    echo "<a href='index.html'>Pagina inicial</a><br>";
    die("Erro ao tentar alterar registro");
}

//Fechar a conexão
mysqli_close($strcon);

//Redirecionar para a pagina de consulta apos 5 segundos:
header("refresh:5;url=consulta.html");

?>