<?php  

$servidor = "localhost";
$usuario = "thyago";
$senha = "123";
$banco = "banco_teste";

$strcon = mysqli_connect($servidor, $usuario, $senha, $banco);

if (!$strcon){
    die("banco de dados inacesível");
}



?>