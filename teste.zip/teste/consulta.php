<?php
//Include para consultar arquivo de acesso ao banco de dados
include_once("conexao.php");

echo "<table>";
echo "<tr>";
echo "<th>NOME<th>";
echo "<th>SOBRENOME<th>";
echo "<th>SEXO<th>";
echo "<th>CPF<th>";
echo "</tr>";


$sql = "SELECT * FROM Cadastro";
$res = mysqli_query($strcon, $sql) or die("Erro ao retornar dados");

    while ($registro = mysqli_fetch_array($res)) {
        $nome = $registro['NomeCliente'];
        $sobrenome = $registro['SobrenomeCliente'];
        $sexo = $registro['SexoCliente'];
        $cpf = $registro['CPF'];
        echo "<tr>";
        echo "<td>".$nome."</td>";
        echo "<td>".$sobrenome."</td>";
        echo "<td>".$sexo."</td>";
        echo "<td>".$cpf."</td>";
        echo "</tr>";
    }

    echo"</table>";
    mysqli_close($strcon);

    echo"<br><a href='index.html'>Página Inicial</a>";
    echo"<br><a href='atualizar.html'>Atualizar Registro</a>";

    ?>