   
   /* Função para desforcar o fundo */
   
   // Seleciona o main e o footer
   const main = document.querySelector('main');
   const footer = document.querySelector('footer');

   // Função para aplicar o desfoque
   function applyBlur() {
       main.style.filter = 'blur(5px)';
       footer.style.filter = 'blur(5px)';
   }

   // Função para remover o desfoque
   function removeBlur() {
       main.style.filter = 'none';
       footer.style.filter = 'none';
   }

   // Seleciona o header e os submenu containers
   const header = document.querySelector('header');
   const submenuContainers = document.querySelectorAll('.submenu-container');

   // Adiciona os eventos de mouseover e mouseout para o menu principal e submenus
   header.addEventListener('mouseover', (event) => {
       if (event.target.closest('nav ul li')) {
           applyBlur();
       }
});

   header.addEventListener('mouseout', (event) => {
       if (event.target.closest('nav ul li')) {
           removeBlur();
       }
});

   submenuContainers.forEach(submenu => {
       submenu.addEventListener('mouseover', applyBlur);
       submenu.addEventListener('mouseout', removeBlur);
});

/* ========================================================= */


