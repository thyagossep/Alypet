<html lang="pt-br">
<head>
    <title>Registrar-se</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
<a href="index.php">Página Inicial</a><br>

<?php
include("conexao.php");

if(isset($_POST['submit'])) {

    $nomeSobrenome = $_POST['name'];
    $email = $_POST['email'];
    $datadenasc = $_POST['datadenascimento'];
    $cpf = $_POST['cpf'];
    $senha = $_POST['password'];

    if($nomeSobrenome == "" || $email == "" ||$datadenasc == "" || $cpf == "" || $senha == ""  ) {
        echo "Todos os campos devem ser preenchidos. Um ou mais campos estão vazios.";
        echo "<br>";
        echo "<a href='registrar.php'>Voltar</a>";
    }
    else {
        $hashsenha = trim(password_hash($senha, PASSWORD_DEFAULT)); // criptografa senha com algoritmo bcrypt
        $sql = "INSERT INTO tbl_cadastro(nome_Sobrenome_Cliente, cpf, data_Nascimento, email_Cliente, senha) VALUES('$nomeSobrenome', '$cpf', '$datadenasc, '$email', '$hashsenha')";
        mysqli_query($strcon, $sql) or die("Não é possível executar a consulta solicitada.");
        echo "Registro efetuado com sucesso!<br>";
        echo "<a href='login.php'>Login</a>";
    }
}
else {
?>
    <p><font size="+2">Registrar</font></p>
    <form name="tbl_cadastro" method="POST" action="" enctype="multipart/form-data">
        <table width="75%" border="0">
            <tr>
                <td width="10%">Nome e Sobrenome</td>
                <td><input type="text" name="name"></td>
            </tr>
            <tr>
                <td>CPF</td>
                <td><input type="text" name="cpf"></td>
            </tr> 
            <tr>
                <td>Data de Nascimento</td>
                <td><input type="date" name="datadenascimento"></td>
            </tr> 
            <tr>
                <td>Email</td>
                <td><input type="text" name="email"></td>
            </tr>    
            <tr>
                <td>Senha</td>
                <td><input type="password" name="password"></td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td><input type="submit" name="submit" value="Registrar"></td>
            </tr>
        </table>
    </form>
<?php
}
?>
</body>
</html>