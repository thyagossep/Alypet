<?php

$servidor = 'localhost';
$nomeBanco = 'db_colecao';
$usuario = 'thyago';
$senha = '123';


$strcon = mysqli_connect($servidor, $usuario, $senha, $nomeBanco);

?>