<?php session_start(); ?>
<html lang="pt-br">
<head>
    <title>Homepage</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
    <div id="header">
        Bem-vindo à nossa loja virtual!
    </div>
    <?php
    if(isset($_SESSION['valid'])) {
        include("conexao.php");
        $result = mysqli_query($strcon, "SELECT * FROM cadastro");
    ?>   
        Bem-vindo <?php echo $_SESSION['name'] ?> ! <a href='logout.php'>Logout</a><br>
        <br>
        <a href='vizualizar.php'>Visualizar e Adicionar Produtos</a>
        <br><br>
        <a href='editarCadastro.php'>Alterar Cadastro</a>
        <br><br>
    <?php
    }
    else {
        echo "Você precisa estar logado para visualizar o conteúdo.<br><br>";
        echo "<a href='login.php'>Login</a> | <a href='registrar.php'>Registrar-se</a>";
    }
    ?>
</body>
</html>