<?php session_start();

    if(!isset($_SESSION['valid'])) {
        header('Location: login.php');
    }

    $login_id= $_SESSION['id'];

    include_once("conexao.php");

    if(isset($_POST['update'])){
        $nome = $_POST['name'];
        $sobrenome = $_POST ['sobrenome'];
        $cpf = $_POST['cpf'];
        $email = $_POST['email'];
        $endereco = $_POST ['endereco'];
        $cep = $_POST ['cep'];
        $cidade = $_POST ['cidade'];
        $hashsenha = trim(password_hash($_POST['senha'], PASSWORD_DEFAULT));

        //Verificar se há campos vazios:
        if(empty($nome) || empty($email) || empty($senha)){
            
            if(empty($nome)){
                echo "<font color='red'>Falta seu Nome.</font><br>";
            }
    
            if(empty($email)){
                echo "<font color='red'>Falta seu Email.</font><br>";
            }
    
            if(empty($senha)){
                echo "<font color='red'>Senha não informada.</font><br>";
            }
        }
        else{
            //Atualizar a tabela
            $sql = "UPDATE cadastro SET nome='$nome', sobrenome='$sobrenome, cpf='$cpf', email='$email', endereco='$endereco', cep='$cep', cidade='$cidade',  senha='$hashsenha' WHERE id=$login_id";
            $result = mysqli_query($strcon, $sql);

            //Alterar array $_SESSION para exibir novo valor ao carregar página inicial
            $_SESSION['name'] = $nome;

            //Redirecionar para a inicial
            header("Location: index.php");
        }
    }
    //Selecionar dados associados com o id em particular:
    $result = mysqli_query($strcon, "SELECT * FROM cadastro WHERE id=$login_id");

    while($res = mysqli_fetch_array($result)){
        $nome = $res['nome'];
        $usuario = $res['usuario'];
        $email = $res['email'];
    }

    ?>
    <!DOCTYPE html>
    <html lang="pt-br">
    <head>
        <title>Editar Cadastro</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="estilo.css" rel="stylesheet" type="text/css">
    </head>
    <body>
    <a href="index.php">Home</a>
    <a href="vizualizar.php">Ver Produtos</a>
    <a href="logout.php">Logout</a>
    <br><br>
    
       <img src="<?php if(empty($foto)){echo "imagens/nice.png";} else{echo $foto;}?>" width='150' height='150'><br>
        <form name="editarCadastro" method="POST" action="editarCadastro.php">
            <table border="0">
            <tr>
                <td>Usuario</td>
                    <td><?php echo $usuario;?></td>
                </tr>
                <tr>
                    <td>Nome</td>
                    <td><input type="text" name="nome"value="<?php echo $nome;?>"></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td><input type="text" name="email" value="<?php echo $email;?>"></td>
                </tr>
               <tr>
                    <td>Senha</td>
                    <td><input type="password" name="senha" required></td>
                </tr>
                
    </body>
    </html>