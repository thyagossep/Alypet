<?php session_start();

if(!isset($_SESSION['valid'])) {
    header('Location: login.php');
}

//Incluir o arquivo de conexão ao banco de dados:
include_once("conexao.php");

//buscar os dados em ordem descendente (entrada mais recente primeiro)
$sql = "SELECT * FROM produtos WHERE id_usuario=".$_SESSION['id']." ORDER BY id DESC";

$resultado = mysqli_query($strcon, $sql);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>Consulta Produtos</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="estilo.css">
</head>

<body>
    <a href="index.php">Início</a> | <a href="add.html">Adicionar Produtos</a> | <a href="logout.php">Logout</a>
    <br><br>

    <table width='80%' border=0>
        <tr bgcolor='#CCCCCC'>
            <td>Item</td>
            <td>Quantidade</td>
            <td>Preço (R$)</td>
            <td>Data Aquisição</td>
            <td>Mais</td>
            <td>Atualizar</td>
        </tr>
    <?php
    while($res = mysqli_fetch_array($resultado)) {
        echo "<tr>";
        echo "<td>".$res['item']."</td>";
        echo "<td>".$res['qtd']."</td>";
        echo "<td>".$res['preco']."</td>";
        echo "<td>".$res['dataAquisicao']."</td>";
        echo "<td><a href=\"editar.php?id=$res[id]\">Editar</a> |
        <a href=\"excluir.php?id=$res[id]\"onClick=\"return confirm('Tem certeza de que você deseja excluir?')\">Excluir</a></td>";
    }
    ?>
    </table>
</body>
</html>