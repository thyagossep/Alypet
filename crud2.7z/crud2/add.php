<?php session_start();

if(!isset($_SESSION['valid'])) {
    header('Location: login.php');
}
?>

<html lang="pt-br">
<head>
    <title>Adicionar Dados</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css.css">
</head>

<body>
<?php
include_once("conexao.php");

if(isset($_POST['Submit'])){
    $item = $_POST['item'];
    $qtd = $_POST['qtd'];
    $preco = $_POST['preco'];
    $dataAquisicao = $_POST['dataAquisicao'];
    $mais = $_POST = ['mais'];
    $id_usuario = $_SESSION['id'];

    // Verificar se há campos vazios
    if(empty($item) || empty($qtd) || empty($preco)) {

        if(empty($item)){
            echo "<font color='red'>Campo Nome está vazio.</font><br>";
        }

        if(empty($qtd)){
            echo "<font color='red'>Campo Quantidade está vazio.</font><br>";
        }

        if(empty($preco)){
            echo "<font color='red'>Campo Preço está vazio.</font><br>";
        }

        if(empty($dataAquisicao)){
            echo "<font color='red'>Campo Data está vazio.</font><br>";
        }

        if(empty($mais)){
            echo "<font color='red'>Campo mais está vazio.</font><br>";
        }

      
        //Link para a página anterior
        echo "<br/><a href='javascript:self.history.back();'>Voltar</a>";
    }
    else {
        // Se todos os campos estiverem preenchidos (não-vazios)

        //Inserir os dados no banco de dados
        $sql = "INSERT INTO produtos(item, qtd, preco, dataAquisicao, mais, id_usuario)
        VALUES('$item', '$qtd', '$preco', '$dataAquisicao', '$mais', '$id_usuario')";

        $result = mysqli_query($strcon,$sql);

        //Mostrar mensagem de sucesso na operação
        echo "<font color='green'>Dados adiciondos com sucesso";
        echo "<br><a href='ver.php'>Ver Produtos</a>";
    }
}
?>
</body>
</html>