<?php session_start(); ?>
<!DOCTYPE html>
<html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>PaginaInicial</title>

        <link rel="stylesheet" href="principal.css">
        <link rel="stylesheet" href="caberoda.css">
        <link rel="stylesheet" href="pinicial.css">
        
    </head>

    
    <body>
        <!-- Cabeçalho -->
        <header>
            <div class="topo">
                <img src="IMG/Logo2.png" alt="50">
                <form class="pesquisa">
                    <label for="pesquisa"></label>
                    <input type="search" id="pesquisa" name="pesquisa" placeholder="Pesquisa"><br>
                </form>
                <div class="inicio">
                    <img src="IMG/loja-de-animais-de-estimacao.png" height="30">
                    <img src="IMG/user.png" height="30">
                    
                    <!-- Container que envolve o parágrafo e a notificação -->
                    <div class="hover-container">
                        <p class="hover-trigger">Entrar ou Cadastrar-se</p>
                        <div class="liberado">  
                            <div class="notificacao">
                                <a href="login.html" class="btn">Entrar</a>
                                <span></span>
                                <p> Não tem Cadastro? <a href="cadastro.html">Criar Conta</a></p>
                            </div> 
                        </div>
                    </div>
                    
                </div>
            </div>
            
            
                    <nav>
                        <ul>
                            <li><a href="cachorro.html"> Cachorro </a>
                                <div class="submenu-container">
                                    <ul class="dropdown">
                                        <li><a href="racaoC.html"> Ração </a></li>
                                        <li><a href="brinquedosC.html"> Brinquedos </a></li>
                                        <li><a href="coleiras.html"> Coleiras, Guias e Peitorais </a></li>
                                        <li><a href="roupasC.html"> Roupas </a></li>
                                        <li><a href="farmaciaC.html"> Farmacia </a></li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                        <ul>
                            <li><a href="gato.html"> Gato </a>
                                <div class="submenu-container">
                                    <ul class="dropdown">
                                        <li><a href="racaoG.html"> Ração </a></li>
                                        <li><a href="petiscos.html"> Petiscos </a></li>
                                        <li><a href="areia.html"> Areia e Banheiros </a></li>
                                        <li><a href="roupasG.html"> Roupas </a></li>
                                        <li><a href="farmaciaG.html"> Farmacia </a></li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                        <ul>
                            <li><a href="peixe.html"> Peixe </a>
                                <div class="submenu-container">
                                    <ul class="dropdown">
                                        <li><a href="alimentacaoPX.html"> Alimentação </a></li>
                                        <li><a href="petiscos.html"> Equipamentos e Acessorios</a></li>
                                        <li><a href="areia.html"> Areia e Banheiros </a></li>
                                        <li><a href="roupasG.html"> Roupas </a></li>
                                        <li><a href="farmaciaG.html"> Farmacia </a></li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                        <ul>
                            <li><a href="passaro.html"> Pássaro </a>
                                <div class="submenu-container">
                                    <ul class="dropdown">
                                        <li><a href="alimentaçãoPS.html"> Alimentação </a></li>
                                        <li><a href="brinquedosPS.html"> Brinquedos e Poleiros </a></li>
                                        <li><a href="acessoriosPS.html"> Acessósrios </a></li>
                                        <li><a href="gaiolas.html"> Gaaíolas e Viveiros </a></li>
                                        <li><a href="farmaciaPS.html"> Farmacia </a></li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                        <ul>
                            <li><a href="banho&tosa.html"> Banho e Tosa </a>
                             
                            </li>
                        </ul>   
                    </nav>  
              

                   

        </header>
        <!-- Cabeçalho -->

        <br><br><br>

        <main>
            
                <div class="img-img">
                    <a href="banho&tosa.html"><img src="IMG/Banho e Tosa.png" width="500px" height="auto"></a>
                    <a href="pagamentosreembolso.html"><img src="img/anuncio raçao.png" width="500px" height="auto"></a>
                </div>

                <br><br><br><br><br><br>

            

                <div class="texto">
                    <h1>Produtos</h1>

                </div>

                
                
                <div class="selecionados">
                    <fieldset>
                        <a href="produtoselecionado.html"><img src="img/ração1.png" width="250px"></a>
                        <br>
                        <p>Pedigree Equilíbrio Natural para Cães Adultos de Raças Médias e Grandes</p>
                        <p>R$ 120,00</p>
                    </fieldset>

                    <fieldset>
                        <a href="pagamentosreembolso.html"><img src="img/racao tutano1.webp" width="250px"></a>
                        <br>
                        <p>Ração Nutron Pet Tutano Premium Plus para Cães Filhotes</p>
                        <p>R$ 85,00</p>
                    </fieldset>

                    <fieldset>
                        <a href="pagamentosreembolso.html"><img src="img/racao gato premi.webp" width="250px"></a>
                        <br>
                        <p>Ração Premier Ambientes Internos Gatos Adultos Frango</p>
                        <p>R$ 95,00</p>
                    </fieldset>  

                    <fieldset>
                        <a href="pagamentosreembolso.html"><img src="img/arranhadoe2.jfif" width="250px"></a>
                        <br>
                        <p>Arranhador Para Gatos</p>
                        <p>R$ 150,00</p>
                    </fieldset>

                    <fieldset>
                        <a href="pagamentosreembolso.html"><img src="img/WHISKAS1.webp" width="250px"></a>
                        <br>
                        <p>Ração Whiskas Para Gatos Adultos Sabor Peixe Triplo Controle</p>
                        <p>R$ 55,00</p>
                    </fieldset>

                    <fieldset>
                        <a href="pagamentosreembolso.html"><img src="img/brinquedob.jpg" width="250px"></a>
                        <br>
                        <p>Brinquedo Líder Pet Halteres Cravo para Cães - Cores Sortidas</p>
                        <p>R$ 35,00</p>
                    </fieldset>

                    <fieldset>
                        <a href="pagamentosreembolso.html"><img src="img/brinquedo2.webp" width="250px"></a>
                        <br>
                        <p>Pet Corda Mordedor Interativo</p>
                        <p>R$ 40,00</p>
                    </fieldset>

                    <fieldset>
                        <a href="pagamentosreembolso.html"> <img src="img/brinquedo3.jfif" width="250px"></a>
                        <br>
                        <p>Brinquedo Interativo Pet Games (PetBall) Para Cães Tamnaho Único</p>
                        <p>R$ 45,00</p>
                    </fieldset>

                    <fieldset>
                        <a href="pagamentosreembolso.html"><img src="img/remedioc2.webp" width="250px"></a>
                        <br><br>
                        <p>Vermífugo Milbemax C para Cães</p>
                        <p>R$ 60,00</p>
                    </fieldset>

                    <fieldset>
                        <a href="pagamentosreembolso.html"><img src="img/roupa3.jfif" width="250px"></a>
                        <br>
                        <p>Roupa Para Cachorro Unissex Tamnho P</p>
                        <p>R$ 80,00</p>
                    </fieldset>

                    <fieldset>
                        <a href="pagamentosreembolso.html"> <img src="img/roupa1.webp" width="250px"></a>
                        <br>
                        <p>Roupa Para Cachoro Unissex Tamnho P</p>
                        <p>R$ 90,00</p>
                    </fieldset>

                    <fieldset>
                        <a href="pagamentosreembolso.html"> <img src="img/roupa2.jpg" width="250px"></a>
                        <br>
                        <p>Roupa Para Cachorro Unissex Tamnho P</p>
                        <p>R$ 100,00</p>
                    </fieldset>

                    <fieldset>
                        <a href="pagamentosreembolso.html"><img src="img/remedio4.png" width="250px"></a>
                        <br><br>
                        <p>Antibiótico Chemitril 50mg para Cães e Gatos Chemitec 10 comprimidos</p>
                        <p>R$ 70,00</p>
                    </fieldset>

                    <fieldset>
                        <a href="pagamentosreembolso.html"><img src="img/remedio3.webp" width="250px"></a>
                        <br>
                        <p>Otospan Solução Otológica para cães e gatos </p>
                        <p>R$ 75,00</p>
                    </fieldset>
                </div>

                <br><br><br>


                <div class="icones" style="text-align: center;">
                    <a href="produtoselecionado.html"> <img id="dog" src="img/dogof1.png" width="150px">
                    <img id="cat" src="img/cat.png" width="150px">
                    <img id="fish" src="img/fish.png" width="150px">
                    <img id="bird" src="img/bird.png" width="150px">

                </div>
                

        <br><br><br><br><br><br>
            <section class="marcas1">
                <div class="marcas1">
                    <img src="img/friskies.jfif" width="200px">
                    <img src="img/guabi_natural.png" width="200px">
                    <img src="img/pedigree.png" width="200px">
                    <img src="img/Royal.png" width="200px">
                    <img src="img/TUTANO.png"width="200px">
                    <img src="img/PremieRpet.png" width="200px">
                    <img src="img/Whiskas.png" width="200px">
                    <img src="img/CatShow.png" width="200px">
                </div>

                <div class="taxidog">
                    <img src="img/taxidog-removebg-preview.png"width="280">
                </div>
            </section>
       
        </main>
    
         <!-- Rodapé -->
         <footer>
            <div class="pata">
                <img src="IMG/pegada.svg" alt="pata" width="130" height="230">
            </div>

            <div class="rodape-conteudo">
                <!-- Conteúdo das Listas -->
                <div class="baixo">
                    <div class="baixo1">
                        <p> <strong> Institucional </strong> </p>
                        <ul>
                            <li> <a href="">Sobre Nós</a> </li>
                            <li><a href=""> Mapa do Site </a> </li>
                        </ul>
                    </div>
                    <div class="baixo1">
                        <p><strong>Políticas </strong> </p>
                        <ul>
                            <li><a href="entregafrete.html">Entrega e Frete </a></li>
                            <li><a href="pagamentosreembolso.html"> Pagamentos e Reembolso </a></li>
                            <li><a href="politicasprivacidade.html"> Políticas de Privacidade </a></li>
                        </ul>
                    </div>
                    <div class="baixo1">
                        <p><strong> Ajuda </strong> </p>
                        <ul>
                            <li><a href="atendimento.html">Atendimento</a></li>
                            <li><a href="meuspedidos.html"> Meus Pedidos </a></li>
                            <li><a href="meucadastro.html"> Meu Cadastro </a></li>
                        </ul>
                    </div>
                </div>

                

                <!-- Código QR do WhatsApp -->
                <div class="code">
                    <li><strong>
                        Entre em Contato <br>
                        Via WhatsApp
                    </strong></li>
                    <a href="https://wa.me/+5511970352208" target="_blank">
                        <img src="IMG/frame.png" alt="QR whatsapp" height="200" width="180">
                    </a>
                </div>
            </div>
            <div class="redesociais">
                    <p><strong>Redes Sociais</strong></p>
                    <a href=""><img src="IMG/linkedin-removebg-preview.png" alt="whatsapp" height="45"></a>
                    <a href="https://www.instagram.com/"><img src="IMG/insta-removebg-preview.png" alt="instagram" height="45"></a>
                    <a href=""><img src="IMG/tiktok-removebg-preview.png" alt="instagram" height="45"></a>
                </div>
          
        </footer>  
        <!-- Rodapé -->
        <script src="desfoque.js" defer></script>
    </body>  
</html>